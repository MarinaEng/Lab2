var container; //ссылка на элемент веб страницы в котором будет отображаться графика

var camera, scene, renderer; //переменные - камера, сцена и отрисовщик

var loader = new THREE.TextureLoader(); //создание загрузчика текстур

var keyboard = new THREEx.KeyboardState();

var planets = [];

var follow = 0;
var switchSpeed = 1.0;
var cameraDefaultPosition = new THREE.Vector3 (0, 100, 0);
var cameraDefaultLook = new THREE.Vector3 (0, 0, 0);
var cameraCurrentLook = new THREE.Vector3 (0, 0, 0);

var clock = new THREE.Clock();

init(); //функция иницилизации камеры, отрисовщика, объектов сцены и тд

animate(); //обновление данных по таймеру браузера

function init()
{
    container = document.getElementById('container'); //получение ссылки на элемент html страницы
    scene = new THREE.Scene(); //создание сцены
    
    /*установка параметров камеры
    45 - угол обзора
    window.innerWidth/window.innerHeight - соотношение сторон
    1 - 4000 - ближняя и дальняя плоскости отсечения */ 
    camera = new THREE.PerspectiveCamera(45,window.innerWidth/window.innerHeight, 1, 4000);

    camera.position.set(0,100,0); //установка позиции камеры

    camera.lookAt(new THREE.Vector3(0, 0.0, 0)); //установка точки, на которую камера будет смотреть

    renderer = new THREE.WebGLRenderer ({antialias:false}); //создание отрисовщика
    renderer.setSize(window.innerWidth, window.innerHeight);

    renderer.setClearColor( 0xffffffff, 1 ); //закрашивание экрана синим цветом

    container.appendChild( renderer.domElement );

    window.addEventListener( 'resize', onWindowResize, false ); //добавление функции обработки события изменения размеров окна

    /*
    var spotlight = new THREE.PointLight ( 0xffffff ); //создание тотечного источника освещения
    spotlight.position.set( 0, 0, 0); //установка позиции источника освещения
    scene.add( spotlight ); //добавление источника в сцену
    */
   
    create_object("imgs/sunmap.jpg", 7);
    create_object("imgs/starmap.jpg", 500);

    create_planet("imgs/mercury/mercurymap.jpg", 1, 10, 2, 2);
    create_planet("imgs/venus/venusmap.jpg", 2, 20, 1.5, 1.5);
    create_planet("imgs/earth/earthmap1k.jpg", 3, 30, 1, 1);
    create_planet("imgs/mars/marsmap1k.jpg", 2.5, 40, 0.8, 0.8);
}

function create_planet(texture_name, radius, distance, a1, a2)
{
    var geometry = new THREE.SphereGeometry( radius, 32, 32 );

    var tex = loader.load( texture_name );
    tex.minFilter = THREE.NearestFilter;

    var material = new THREE.MeshBasicMaterial({
        map: tex,
        side: THREE.DoubleSide
    })

    var sphere = new THREE.Mesh( geometry, material );

    sphere.position.set( distance, 0, 0 );

    scene.add( sphere );

    var planet = {};

    planet.model = sphere;
    planet.orbit = distance;
    planet.s1 = a1;
    planet.a1 = 0.0;
    planet.s2 = a2;
    planet.a2 = 0.0;

    planets.push(planet);
}

function create_object(texture_name, radius)
{
    var geometry = new THREE.SphereGeometry( radius, 32, 32 );

    var tex = loader.load( texture_name );
    tex.minFilter = THREE.NearestFilter;

    var material = new THREE.MeshBasicMaterial({
        map: tex,
        side: THREE.DoubleSide
    })

    var sphere = new THREE.Mesh ( geometry, material );

    scene.add( sphere );
}

function onWindowResize()
{
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();

    renderer.setSize( window.innerWidth, window.innerHeight);
}

function animate()
{
    var delta = clock.getDelta(); //возвращает время, прошедшее с момента предыдущего вызова этой функции
    
    for (var i = 0; i < planets.length; i++) // перебор планет
    {
        var m = new THREE.Matrix4(); //создание набора матриц
        var m1 = new THREE.Matrix4();
        var m2 = new THREE.Matrix4();

        planets[i].a1 += planets[i].s1 * delta;
        planets[i].a2 += planets[i].s2 * delta;
          

        m1.makeRotationY(planets[i].a1); // создание матрицы поворота (вокруг оси Y) в m1 и матрицы перемещения в m2 
        m2.setPosition(new THREE.Vector3(planets[i].orbit, 0, 0));
                 
        m.multiplyMatrices(m1, m2); // запись результата перемножения m1 и m2 в m  
        m1.makeRotationY(planets[i].a2);
        m.multiplyMatrices(m, m1);

                   
        planets[i].model.matrix = m; // установка m в качестве матрицы преобразований объекта object
        planets[i].model.matrixAutoUpdate = false;

    }

    keys(delta);

    requestAnimationFrame( animate );
    render();
}

function render()
{
    renderer.render (scene, camera );
}

function keys(delta)
{
    if (keyboard.pressed("1")) 
    {
        follow = 1;
    }             
    
    if (keyboard.pressed("2")) 
    {
        follow = 2;
    }     

    if (keyboard.pressed("3")) 
    {
        follow = 3;
    }     

    if (keyboard.pressed("4")) 
    {
        follow = 4;
    }     

    if (keyboard.pressed("0")) 
    {
        follow = 0;
    }  

    if(follow == 0)
    {

        camera.position.lerp(cameraDefaultPosition, delta * switchSpeed );
        
        //camera.lookAt.lerp(cameraDefaultLook, delta * switchSpeed);

        //var look = new THREE.Vector3(0, 0, 0);

        cameraCurrentLook.lerp(cameraDefaultLook, delta * switchSpeed)

        camera.lookAt(cameraDefaultLook);
    }


    if(follow > 0)
    {
        var planet = planets[follow-1];

        if (planet != null)
        {
            var m = new THREE.Matrix4(); //получение матрицы позиции из матрицы объекта
            m.copyPosition(planet.model.matrix);
                    
            var pos = new THREE.Vector3(0, 0, 0); //получение позиции из матрицы позиции
            pos.setFromMatrixPosition(m);
            
            var cpos = new THREE.Vector3 (0, 0, 0); 

            cpos.x = pos.x + 10 * Math.cos(-planet.a1);
            cpos.z = pos.z + 10 * Math.sin(-planet.a1); 
            cpos.y = 0;

            //camera.position.copy(cpos);

            camera.position.lerp(cpos, delta * switchSpeed );

            camera.lookAt(pos); 
            cameraCurrentLook.copy(pos)
        }
    }
}
